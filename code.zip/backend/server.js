const express = require("express")
const http = require("http")
const socketIo = require("socket.io")
const cors = require("cors")
const jwt = require("jsonwebtoken")
const bcrypt = require("bcryptjs")
const multer = require("multer")
const cloudinary = require("cloudinary").v2
const dotenv = require("dotenv")
const { neon } = require("@neondatabase/serverless")

dotenv.config()

const app = express()
const server = http.createServer(app)
const io = socketIo(server, {
  cors: { origin: process.env.FRONTEND_URL || "http://localhost:3000" },
})

// Middleware
app.use(cors())
app.use(express.json())
app.use(express.urlencoded({ extended: true }))

// Cloudinary config
cloudinary.config({
  cloud_name: process.env.CLOUDINARY_NAME,
  api_key: process.env.CLOUDINARY_API_KEY,
  api_secret: process.env.CLOUDINARY_API_SECRET,
})

// Database
const sql = neon(process.env.NEON_DATABASE_URL)

// Multer config for file uploads
const upload = multer({ storage: multer.memoryStorage() })

// JWT Middleware
const verifyToken = (req, res, next) => {
  const token = req.headers.authorization?.split(" ")[1]
  if (!token) return res.status(401).json({ message: "No token provided" })

  try {
    const decoded = jwt.verify(token, process.env.JWT_SECRET)
    req.userId = decoded.id
    next()
  } catch (error) {
    res.status(401).json({ message: "Invalid token" })
  }
}

// Socket.io Auth
io.use((socket, next) => {
  const token = socket.handshake.auth.token
  if (!token) return next(new Error("No token"))

  try {
    const decoded = jwt.verify(token, process.env.JWT_SECRET)
    socket.userId = decoded.id
    socket.username = decoded.username
    next()
  } catch (error) {
    next(new Error("Invalid token"))
  }
})

// ============ REST API Routes ============

// Auth Routes
app.post("/api/auth/signup", async (req, res) => {
  try {
    const { username, email, password } = req.body

    const hashedPassword = await bcrypt.hash(password, 10)

    const result = await sql(
      "INSERT INTO users (username, email, password) VALUES ($1, $2, $3) RETURNING id, username, email",
      [username, email, hashedPassword],
    )

    res.status(201).json({ message: "User created successfully", user: result[0] })
  } catch (error) {
    res.status(500).json({ message: error.message })
  }
})

app.post("/api/auth/login", async (req, res) => {
  try {
    const { email, password } = req.body

    const users = await sql("SELECT * FROM users WHERE email = $1", [email])
    if (users.length === 0) {
      return res.status(401).json({ message: "Invalid credentials" })
    }

    const user = users[0]
    const isValidPassword = await bcrypt.compare(password, user.password)

    if (!isValidPassword) {
      return res.status(401).json({ message: "Invalid credentials" })
    }

    const token = jwt.sign({ id: user.id, username: user.username }, process.env.JWT_SECRET)

    res.json({
      token,
      user: { id: user.id, username: user.username, email: user.email },
    })
  } catch (error) {
    res.status(500).json({ message: error.message })
  }
})

// User Routes
app.get("/api/users/search", verifyToken, async (req, res) => {
  try {
    const { query } = req.query
    const users = await sql(
      "SELECT id, username, email FROM users WHERE username ILIKE $1 OR email ILIKE $1 LIMIT 10",
      [`%${query}%`],
    )
    res.json(users)
  } catch (error) {
    res.status(500).json({ message: error.message })
  }
})

// File Upload
const fileUploadHandler = async (req, res) => {
  try {
    if (!req.file) return res.status(400).json({ message: "No file provided" })

    const uploadStream = cloudinary.uploader.upload_stream(
      {
        resource_type: "auto",
        folder: "chatflow",
        max_bytes: 104857600, // 100MB limit
      },
      (error, result) => {
        if (error) {
          console.error("Cloudinary error:", error)
          return res.status(500).json({ message: "Upload failed", error: error.message })
        }
        res.json({
          url: result.secure_url,
          publicId: result.public_id,
          type: result.resource_type,
        })
      },
    )

    uploadStream.end(req.file.buffer)
  } catch (error) {
    console.error("Upload error:", error)
    res.status(500).json({ message: error.message })
  }
}

app.post("/api/upload", verifyToken, upload.single("file"), fileUploadHandler)

// n8n Webhook
const triggerN8nWebhook = async (event, data) => {
  if (!process.env.N8N_WEBHOOK_URL) return

  try {
    await fetch(process.env.N8N_WEBHOOK_URL, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ event, data, timestamp: new Date().toISOString() }),
    })
  } catch (error) {
    console.error("Webhook error:", error)
  }
}

// ============ Socket.io Events ============

io.on("connection", (socket) => {
  console.log(`User connected: ${socket.userId}`)

  // Get user conversations
  socket.on("get_conversations", async (callback) => {
    try {
      const conversations = await sql(
        `SELECT c.id, u.username as participantName, m.content as lastMessage 
         FROM conversations c 
         JOIN users u ON (CASE WHEN c.user1_id = $1 THEN c.user2_id ELSE c.user1_id END) = u.id
         LEFT JOIN messages m ON c.id = m.conversation_id
         WHERE c.user1_id = $1 OR c.user2_id = $1
         ORDER BY m.created_at DESC`,
        [socket.userId],
      )
      socket.emit("conversation_list", conversations)
    } catch (error) {
      console.error("Error fetching conversations:", error)
    }
  })

  // Create conversation
  socket.on("create_conversation", async (data, callback) => {
    try {
      const { userId } = data
      const conversationId = `${Math.min(socket.userId, userId)}_${Math.max(socket.userId, userId)}`

      await sql(`INSERT INTO conversations (id, user1_id, user2_id) VALUES ($1, $2, $3) ON CONFLICT DO NOTHING`, [
        conversationId,
        Math.min(socket.userId, userId),
        Math.max(socket.userId, userId),
      ])

      callback(conversationId)

      socket.emit("get_conversations", null, (conversations) => {
        socket.emit("conversation_list", conversations)
      })
    } catch (error) {
      console.error("Error creating conversation:", error)
    }
  })

  // Get messages
  socket.on("get_messages", async (data, callback) => {
    try {
      const { conversationId } = data
      const messages = await sql(`SELECT * FROM messages WHERE conversation_id = $1 ORDER BY created_at ASC`, [
        conversationId,
      ])
      callback(messages)
    } catch (error) {
      console.error("Error fetching messages:", error)
      callback([])
    }
  })

  // Send message
  socket.on("send_message", async (data) => {
    try {
      const { conversationId, content, type, fileName } = data

      const result = await sql(
        `INSERT INTO messages (conversation_id, sender_id, content, type, file_name, created_at) 
         VALUES ($1, $2, $3, $4, $5, NOW()) RETURNING *`,
        [conversationId, socket.userId, content, type, fileName || null],
      )

      const message = {
        ...result[0],
        senderName: socket.username,
      }

      // Emit only to the conversation, not globally
      io.to(conversationId).emit("new_message", message)

      // Trigger n8n webhook
      await triggerN8nWebhook("message_sent", {
        userId: socket.userId,
        conversationId,
        messageType: type,
        timestamp: new Date().toISOString(),
      })
    } catch (error) {
      console.error("Error sending message:", error)
    }
  })

  // Call events
  socket.on("initiate_call", async (data) => {
    const { conversationId } = data
    const otherUser = await sql(`SELECT user1_id, user2_id FROM conversations WHERE id = $1`, [conversationId])

    if (!otherUser || otherUser.length === 0) {
      console.error("Conversation not found")
      return
    }

    const recipientId = otherUser[0].user1_id === socket.userId ? otherUser[0].user2_id : otherUser[0].user1_id
    io.to(`user_${recipientId}`).emit("incoming_call", {
      callerId: socket.userId,
      callerName: socket.username,
      conversationId,
    })

    await triggerN8nWebhook("call_initiated", {
      callerId: socket.userId,
      callerName: socket.username,
      recipientId,
      conversationId,
      timestamp: new Date().toISOString(),
    })
  })

  socket.on("end_call", async (data) => {
    const { conversationId } = data
    io.emit("call_ended", { conversationId })

    await triggerN8nWebhook("call_ended", {
      userId: socket.userId,
      conversationId,
      timestamp: new Date().toISOString(),
    })
  })

  // WebRTC signaling
  socket.on("webrtc_offer", (data) => {
    io.emit("webrtc_offer", data)
  })

  socket.on("webrtc_answer", (data) => {
    io.emit("webrtc_answer", data)
  })

  socket.on("webrtc_ice_candidate", (data) => {
    io.emit("webrtc_ice_candidate", data)
  })

  socket.on("disconnect", () => {
    console.log(`User disconnected: ${socket.userId}`)
  })
})

const PORT = process.env.PORT || 5000
server.listen(PORT, () => {
  console.log(`Server running on port ${PORT}`)
})
