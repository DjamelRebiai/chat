"use client"

import type { Socket } from "socket.io-client"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Send, Paperclip, Mic, X } from "lucide-react"
import MessageList from "./message-list"
import { toast } from "sonner"
import type React from "react"
import { useEffect, useState, useRef } from "react"

interface ChatWindowProps {
  conversationId: string
  socket: Socket | null
}

export default function ChatWindow({ conversationId, socket }: ChatWindowProps) {
  const [messages, setMessages] = useState<any[]>([])
  const [messageText, setMessageText] = useState("")
  const [isRecording, setIsRecording] = useState(false)
  const [isLoading, setIsLoading] = useState(true)
  const [recordingTime, setRecordingTime] = useState(0)
  const mediaRecorderRef = useRef(null)
  const audioChunksRef = useRef([])

  useEffect(() => {
    if (!socket) return

    // Load message history
    socket.emit("get_messages", { conversationId }, (data: any) => {
      setMessages(data)
      setIsLoading(false)
    })

    socket.on("new_message", (message: any) => {
      if (message.conversation_id === conversationId) {
        setMessages((prev) => [...prev, message])
      }
    })

    return () => {
      socket.off("new_message")
    }
  }, [conversationId, socket])

  const sendMessage = () => {
    if (!messageText.trim() || !socket) return

    socket.emit("send_message", {
      conversationId,
      content: messageText,
      type: "text",
    })

    setMessageText("")
  }

  const handleFileUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = e.target.files
    if (!files) return

    for (const file of files) {
      const formData = new FormData()
      formData.append("file", file)

      try {
        const res = await fetch(`${process.env.NEXT_PUBLIC_API_URL}/api/upload`, {
          method: "POST",
          headers: { Authorization: `Bearer ${localStorage.getItem("token")}` },
          body: formData,
        })

        const data = await res.json()

        if (!res.ok) {
          toast.error(data.message || "Upload failed")
          continue
        }

        if (socket) {
          const messageType = file.type.startsWith("image")
            ? "image"
            : file.type.startsWith("video")
              ? "video"
              : file.type.startsWith("audio")
                ? "voice"
                : "file"

          socket.emit("send_message", {
            conversationId,
            content: data.url,
            type: messageType,
            fileName: file.name,
          })
          toast.success("File uploaded successfully")
        }
      } catch (error) {
        toast.error("Upload failed")
      }
    }
  }

  const startRecording = async () => {
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ audio: true })
      const mediaRecorder = new MediaRecorder(stream)
      mediaRecorderRef.current = mediaRecorder
      audioChunksRef.current = []

      mediaRecorder.ondataavailable = (event) => {
        audioChunksRef.current.push(event.data)
      }

      mediaRecorder.onstop = async () => {
        const audioBlob = new Blob(audioChunksRef.current, { type: "audio/webm" })
        const formData = new FormData()
        formData.append("file", audioBlob, `voice_${Date.now()}.webm`)

        try {
          const res = await fetch(`${process.env.NEXT_PUBLIC_API_URL}/api/upload`, {
            method: "POST",
            headers: { Authorization: `Bearer ${localStorage.getItem("token")}` },
            body: formData,
          })

          const data = await res.json()

          if (!res.ok) {
            toast.error("Voice upload failed")
            return
          }

          if (socket) {
            socket.emit("send_message", {
              conversationId,
              content: data.url,
              type: "voice",
              fileName: `voice_${Date.now()}.webm`,
            })
            toast.success("Voice message sent")
          }
        } catch (error) {
          toast.error("Voice upload failed")
        }

        // Stop all tracks
        stream.getTracks().forEach((track) => track.stop())
      }

      mediaRecorder.start()
      setIsRecording(true)
      setRecordingTime(0)

      const interval = setInterval(() => {
        setRecordingTime((prev) => prev + 1)
      }, 1000)

      // Auto-stop after 60 seconds
      const timeout = setTimeout(() => {
        mediaRecorder.stop()
        setIsRecording(false)
        clearInterval(interval)
      }, 60000)

      // Store interval and timeout for cleanup
      mediaRecorderRef.current.interval = interval
      mediaRecorderRef.current.timeout = timeout
    } catch (error) {
      toast.error("Microphone access denied")
    }
  }

  const stopRecording = () => {
    if (mediaRecorderRef.current && isRecording) {
      mediaRecorderRef.current.stop()
      setIsRecording(false)
      clearInterval(mediaRecorderRef.current.interval)
      clearTimeout(mediaRecorderRef.current.timeout)
      setRecordingTime(0)
    }
  }

  return (
    <div className="flex-1 flex flex-col bg-slate-900">
      {isLoading ? (
        <div className="flex-1 flex items-center justify-center">
          <p className="text-slate-400">Loading messages...</p>
        </div>
      ) : (
        <>
          <MessageList messages={messages} />

          <div className="border-t border-slate-700 p-4 space-y-4">
            {isRecording && (
              <div className="flex items-center gap-3 bg-red-500/20 px-4 py-2 rounded border border-red-500/50">
                <div className="w-3 h-3 bg-red-500 rounded-full animate-pulse" />
                <span className="text-sm text-red-300">Recording: {recordingTime}s</span>
              </div>
            )}
            <div className="flex gap-2">
              <Input
                value={messageText}
                onChange={(e) => setMessageText(e.target.value)}
                onKeyPress={(e) => e.key === "Enter" && sendMessage()}
                placeholder="Type a message..."
                className="bg-slate-700/50 border-slate-600"
                disabled={isRecording}
              />
              <label>
                <input
                  type="file"
                  onChange={handleFileUpload}
                  className="hidden"
                  multiple
                  accept="image/*,video/*,audio/*,.pdf,.doc,.docx"
                />
                <Button
                  size="icon"
                  variant="outline"
                  className="border-slate-600 bg-transparent"
                  asChild
                  disabled={isRecording}
                >
                  <Paperclip size={20} />
                </Button>
              </label>

              {isRecording ? (
                <Button onClick={stopRecording} className="bg-red-600 hover:bg-red-700">
                  <X size={20} />
                </Button>
              ) : (
                <Button onClick={startRecording} variant="outline" className="border-slate-600 bg-transparent">
                  <Mic size={20} />
                </Button>
              )}

              <Button onClick={sendMessage} className="bg-blue-600 hover:bg-blue-700" disabled={isRecording}>
                <Send size={20} />
              </Button>
            </div>
          </div>
        </>
      )}
    </div>
  )
}
