"use client"

import { useEffect, useRef, useState } from "react"
import type { Socket } from "socket.io-client"
import { Button } from "@/components/ui/button"
import { PhoneOff, Mic, MicOff, Video, VideoOff } from "lucide-react"

interface VideoCallModalProps {
  callData: any
  socket: Socket | null
  onClose: () => void
}

export default function VideoCallModal({ callData, socket, onClose }: VideoCallModalProps) {
  const localVideoRef = useRef<HTMLVideoElement>(null)
  const remoteVideoRef = useRef<HTMLVideoElement>(null)
  const [callDuration, setCallDuration] = useState(0)
  const [isMuted, setIsMuted] = useState(false)
  const [isVideoEnabled, setIsVideoEnabled] = useState(true)
  const peerConnectionRef = useRef<RTCPeerConnection | null>(null)
  const localStreamRef = useRef<MediaStream | null>(null)

  useEffect(() => {
    const initializeCall = async () => {
      try {
        const localStream = await navigator.mediaDevices.getUserMedia({
          video: isVideoEnabled,
          audio: true,
        })

        localStreamRef.current = localStream

        if (localVideoRef.current) {
          localVideoRef.current.srcObject = localStream
        }

        const configuration = {
          iceServers: [
            { urls: ["stun:stun.l.google.com:19302"] },
            { urls: ["stun:stun1.l.google.com:19302"] },
            { urls: ["stun:stun2.l.google.com:19302"] },
            { urls: ["stun:stun3.l.google.com:19302"] },
          ],
        }

        const peerConnection = new RTCPeerConnection(configuration)
        peerConnectionRef.current = peerConnection

        localStream.getTracks().forEach((track) => {
          peerConnection.addTrack(track, localStream)
        })

        peerConnection.ontrack = (event) => {
          if (remoteVideoRef.current) {
            remoteVideoRef.current.srcObject = event.streams[0]
          }
        }

        peerConnection.onicecandidate = (event) => {
          if (event.candidate) {
            socket?.emit("webrtc_ice_candidate", {
              candidate: event.candidate,
              conversationId: callData.conversationId,
            })
          }
        }

        socket?.emit("webrtc_offer", { conversationId: callData.conversationId })
      } catch (error) {
        console.error("Error accessing media devices:", error)
        alert("Unable to access camera/microphone. Please check your permissions.")
      }
    }

    initializeCall()

    const timer = setInterval(() => {
      setCallDuration((prev) => prev + 1)
    }, 1000)

    return () => clearInterval(timer)
  }, [])

  const handleEndCall = () => {
    if (peerConnectionRef.current) {
      peerConnectionRef.current.close()
    }
    if (localStreamRef.current) {
      localStreamRef.current.getTracks().forEach((track) => track.stop())
    }
    socket?.emit("end_call", { conversationId: callData.conversationId })
    onClose()
  }

  const toggleMute = () => {
    if (localStreamRef.current) {
      const audioTracks = localStreamRef.current.getAudioTracks()
      audioTracks.forEach((track) => {
        track.enabled = !track.enabled
      })
      setIsMuted(!isMuted)
    }
  }

  const toggleVideo = () => {
    if (localStreamRef.current) {
      const videoTracks = localStreamRef.current.getVideoTracks()
      videoTracks.forEach((track) => {
        track.enabled = !track.enabled
      })
      setIsVideoEnabled(!isVideoEnabled)
    }
  }

  const formatTime = (seconds: number) => {
    const mins = Math.floor(seconds / 60)
    const secs = seconds % 60
    return `${mins}:${secs.toString().padStart(2, "0")}`
  }

  return (
    <div className="fixed inset-0 bg-black/80 flex items-center justify-center z-50 p-4">
      <div className="relative w-full max-w-4xl bg-black rounded-lg overflow-hidden shadow-2xl">
        <div className="aspect-video flex bg-slate-900">
          <div className="flex-1 relative bg-slate-950">
            <video ref={remoteVideoRef} autoPlay className="w-full h-full object-cover" />
            <div className="absolute top-4 left-4 bg-black/50 px-3 py-1 rounded text-white text-sm">
              {callData?.callerName || "Caller"}
            </div>
          </div>
        </div>

        <video
          ref={localVideoRef}
          autoPlay
          muted
          className="absolute bottom-20 right-4 w-32 h-32 bg-slate-900 rounded-lg border-2 border-slate-700 object-cover"
        />

        <div className="absolute bottom-0 left-0 right-0 bg-gradient-to-t from-black/80 to-transparent p-4 flex flex-col items-center gap-4">
          <div className="text-white text-lg font-semibold">{formatTime(callDuration)}</div>

          <div className="flex gap-4 justify-center">
            <Button
              onClick={toggleMute}
              className={`rounded-full w-12 h-12 p-0 ${
                isMuted ? "bg-red-600 hover:bg-red-700" : "bg-slate-700 hover:bg-slate-600"
              }`}
            >
              {isMuted ? <MicOff size={20} /> : <Mic size={20} />}
            </Button>

            <Button
              onClick={toggleVideo}
              className={`rounded-full w-12 h-12 p-0 ${
                !isVideoEnabled ? "bg-red-600 hover:bg-red-700" : "bg-slate-700 hover:bg-slate-600"
              }`}
            >
              {isVideoEnabled ? <Video size={20} /> : <VideoOff size={20} />}
            </Button>

            <Button onClick={handleEndCall} className="bg-red-600 hover:bg-red-700 rounded-full w-12 h-12 p-0">
              <PhoneOff size={24} />
            </Button>
          </div>
        </div>
      </div>
    </div>
  )
}
