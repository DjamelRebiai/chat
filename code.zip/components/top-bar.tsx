"use client"

import { Button } from "@/components/ui/button"
import { Phone, Video, MoreVertical, Settings, LogOut } from "lucide-react"
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger } from "@/components/ui/dropdown-menu"
import { useRouter } from "next/navigation"

interface TopBarProps {
  conversation: any
  onCallClick: () => void
}

export default function TopBar({ conversation, onCallClick }: TopBarProps) {
  const router = useRouter()

  if (!conversation) return null

  const handleLogout = () => {
    localStorage.removeItem("token")
    localStorage.removeItem("user")
    router.push("/")
  }

  return (
    <div className="border-b border-slate-700 bg-slate-800/50 p-4 flex justify-between items-center">
      <div>
        <h2 className="text-xl font-semibold">{conversation.participantName}</h2>
        <p className="text-sm text-slate-400">Online</p>
      </div>
      <div className="flex gap-2">
        <Button size="icon" variant="outline" className="border-slate-600 bg-transparent hover:bg-slate-700">
          <Phone size={20} />
        </Button>
        <Button
          size="icon"
          variant="outline"
          className="border-slate-600 bg-transparent hover:bg-slate-700"
          onClick={onCallClick}
        >
          <Video size={20} />
        </Button>

        <DropdownMenu>
          <DropdownMenuTrigger asChild>
            <Button size="icon" variant="outline" className="border-slate-600 bg-transparent hover:bg-slate-700">
              <MoreVertical size={20} />
            </Button>
          </DropdownMenuTrigger>
          <DropdownMenuContent align="end" className="bg-slate-800 border-slate-700">
            <DropdownMenuItem className="text-slate-300 focus:bg-slate-700">
              <Settings size={16} className="mr-2" />
              Settings
            </DropdownMenuItem>
            <DropdownMenuItem onClick={handleLogout} className="text-red-400 focus:bg-slate-700">
              <LogOut size={16} className="mr-2" />
              Logout
            </DropdownMenuItem>
          </DropdownMenuContent>
        </DropdownMenu>
      </div>
    </div>
  )
}
