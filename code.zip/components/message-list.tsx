"use client"

import { useEffect, useRef } from "react"
import { Card } from "@/components/ui/card"
import Image from "next/image"
import { Volume2, Download } from "lucide-react"
import { Button } from "@/components/ui/button"

interface Message {
  id: string
  content: string
  type: "text" | "image" | "file" | "voice" | "video"
  sender_id: number
  senderName?: string
  created_at: string
  file_name?: string
}

export default function MessageList({ messages }: { messages: Message[] }) {
  const endRef = useRef<HTMLDivElement>(null)
  const currentUser = typeof window !== "undefined" ? JSON.parse(localStorage.getItem("user") || "{}") : {}

  useEffect(() => {
    endRef.current?.scrollIntoView({ behavior: "smooth" })
  }, [messages])

  const playVoiceMessage = (url: string) => {
    const audio = new Audio(url)
    audio.play()
  }

  return (
    <div className="flex-1 overflow-y-auto p-4 space-y-4">
      {messages.map((message) => {
        const isOwn = message.sender_id === currentUser.id

        return (
          <div key={message.id} className={`flex ${isOwn ? "justify-end" : "justify-start"}`}>
            <Card
              className={`max-w-xs px-4 py-2 ${
                isOwn ? "bg-blue-600/50 border-blue-500" : "bg-slate-700/50 border-slate-600"
              }`}
            >
              {!isOwn && <p className="text-xs font-semibold text-slate-300 mb-1">{message.senderName}</p>}

              {message.type === "text" && <p>{message.content}</p>}

              {message.type === "image" && (
                <Image
                  src={message.content || "/placeholder.svg"}
                  alt="Shared image"
                  width={300}
                  height={300}
                  className="rounded max-w-full h-auto"
                  crossOrigin="anonymous"
                />
              )}

              {message.type === "video" && (
                <video
                  src={message.content}
                  controls
                  className="rounded max-w-full h-auto max-h-64"
                  crossOrigin="anonymous"
                />
              )}

              {message.type === "voice" && (
                <div className="flex items-center gap-2">
                  <Button
                    size="sm"
                    variant="outline"
                    className="border-slate-600 bg-transparent"
                    onClick={() => playVoiceMessage(message.content)}
                  >
                    <Volume2 size={16} />
                    Play
                  </Button>
                  <span className="text-xs text-slate-400">Voice message</span>
                </div>
              )}

              {message.type === "file" && (
                <a
                  href={message.content}
                  className="text-blue-300 hover:underline flex items-center gap-2 text-sm"
                  download
                >
                  <Download size={16} />
                  {message.file_name || "Download file"}
                </a>
              )}

              <p className="text-xs text-slate-400 mt-1">{new Date(message.created_at).toLocaleTimeString()}</p>
            </Card>
          </div>
        )
      })}
      <div ref={endRef} />
    </div>
  )
}
