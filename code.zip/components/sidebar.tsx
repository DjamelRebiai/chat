"use client"

import { useState } from "react"
import type { Socket } from "socket.io-client"
import { Input } from "@/components/ui/input"
import { Button } from "@/components/ui/button"
import { Card } from "@/components/ui/card"
import { LogOut, Plus } from "lucide-react"
import { useRouter } from "next/navigation"

interface SidebarProps {
  conversations: any[]
  selectedConversation: string | null
  onSelectConversation: (id: string) => void
  socket: Socket | null
}

export default function Sidebar({ conversations, selectedConversation, onSelectConversation, socket }: SidebarProps) {
  const [searchTerm, setSearchTerm] = useState("")
  const [users, setUsers] = useState<any[]>([])
  const [showUserSearch, setShowUserSearch] = useState(false)
  const router = useRouter()

  const handleLogout = () => {
    localStorage.removeItem("token")
    localStorage.removeItem("user")
    router.push("/")
  }

  const searchUsers = async (query: string) => {
    if (!query) {
      setUsers([])
      return
    }

    try {
      const res = await fetch(`${process.env.NEXT_PUBLIC_API_URL}/api/users/search?query=${query}`, {
        headers: { Authorization: `Bearer ${localStorage.getItem("token")}` },
      })
      const data = await res.json()
      setUsers(data)
    } catch (error) {
      console.error("Search error:", error)
    }
  }

  const startConversation = (userId: string) => {
    socket?.emit("create_conversation", { userId }, (conversationId: string) => {
      onSelectConversation(conversationId)
      setShowUserSearch(false)
      setSearchTerm("")
    })
  }

  return (
    <div className="w-64 bg-slate-800 border-r border-slate-700 flex flex-col">
      <div className="p-4 space-y-4">
        <div className="flex items-center justify-between">
          <h1 className="text-xl font-bold bg-gradient-to-r from-blue-400 to-cyan-400 bg-clip-text text-transparent">
            ChatFlow
          </h1>
          <Button
            size="sm"
            variant="outline"
            onClick={() => setShowUserSearch(!showUserSearch)}
            className="border-slate-600"
          >
            <Plus size={18} />
          </Button>
        </div>

        {showUserSearch && (
          <div className="space-y-2">
            <Input
              placeholder="Search users..."
              value={searchTerm}
              onChange={(e) => {
                setSearchTerm(e.target.value)
                searchUsers(e.target.value)
              }}
              className="bg-slate-700/50 border-slate-600"
            />
            <div className="space-y-2 max-h-48 overflow-y-auto">
              {users.map((u) => (
                <Card
                  key={u.id}
                  className="bg-slate-700/50 border-slate-600 p-3 cursor-pointer hover:bg-slate-700 transition"
                  onClick={() => startConversation(u.id)}
                >
                  <p className="font-medium">{u.username}</p>
                  <p className="text-sm text-slate-400">{u.email}</p>
                </Card>
              ))}
            </div>
          </div>
        )}
      </div>

      <div className="flex-1 overflow-y-auto px-4 space-y-2">
        {conversations.map((conv) => (
          <Card
            key={conv.id}
            className={`p-3 cursor-pointer transition ${
              selectedConversation === conv.id
                ? "bg-blue-600/50 border-blue-500"
                : "bg-slate-700/50 border-slate-600 hover:bg-slate-700"
            }`}
            onClick={() => onSelectConversation(conv.id)}
          >
            <p className="font-medium truncate">{conv.participantName}</p>
            <p className="text-sm text-slate-400 truncate">{conv.lastMessage || "No messages"}</p>
          </Card>
        ))}
      </div>

      <div className="p-4 border-t border-slate-700">
        <Button onClick={handleLogout} variant="outline" className="w-full border-slate-600 bg-transparent">
          <LogOut size={18} />
          Logout
        </Button>
      </div>
    </div>
  )
}
