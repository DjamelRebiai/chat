"use client"

import { useEffect, useState } from "react"
import { io, type Socket } from "socket.io-client"
import Sidebar from "./sidebar"
import ChatWindow from "./chat-window"
import TopBar from "./top-bar"
import VideoCallModal from "./video-call-modal"

const SOCKET_URL = process.env.NEXT_PUBLIC_SOCKET_URL || "http://localhost:5000"

export default function ChatLayout() {
  const [socket, setSocket] = useState<Socket | null>(null)
  const [selectedConversation, setSelectedConversation] = useState<string | null>(null)
  const [conversations, setConversations] = useState<any[]>([])
  const [user, setUser] = useState<any>(null)
  const [isCallActive, setIsCallActive] = useState(false)
  const [callData, setCallData] = useState<any>(null)

  useEffect(() => {
    const userData = localStorage.getItem("user")
    if (userData) {
      setUser(JSON.parse(userData))
    }

    const newSocket = io(SOCKET_URL, {
      auth: { token: localStorage.getItem("token") },
      reconnection: true,
      reconnectionDelay: 1000,
    })

    newSocket.on("connect", () => {
      console.log("Connected to socket")
      newSocket.emit("get_conversations", (data: any) => {
        setConversations(data || [])
      })
    })

    newSocket.on("conversation_list", (data) => {
      setConversations(data || [])
    })

    newSocket.on("incoming_call", (data) => {
      setCallData(data)
      setIsCallActive(true)
    })

    newSocket.on("call_ended", () => {
      setIsCallActive(false)
      setCallData(null)
    })

    setSocket(newSocket)

    return () => {
      newSocket.disconnect()
    }
  }, [])

  return (
    <div className="flex h-screen bg-slate-900 text-white">
      <Sidebar
        conversations={conversations}
        selectedConversation={selectedConversation}
        onSelectConversation={setSelectedConversation}
        socket={socket}
      />
      <div className="flex-1 flex flex-col">
        {selectedConversation ? (
          <>
            <TopBar
              conversation={conversations.find((c) => c.id === selectedConversation)}
              onCallClick={() => socket?.emit("initiate_call", { conversationId: selectedConversation })}
            />
            <ChatWindow conversationId={selectedConversation} socket={socket} />
          </>
        ) : (
          <div className="flex-1 flex items-center justify-center">
            <p className="text-slate-400">Select a conversation to start chatting</p>
          </div>
        )}
      </div>
      {isCallActive && <VideoCallModal callData={callData} socket={socket} onClose={() => setIsCallActive(false)} />}
    </div>
  )
}
